/usr/bin/cmake --no-warn-unused-cli -DCMAKE_BUILD_TYPE:STRING=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS:BOOL=TRUE -DCMAKE_C_COMPILER:FILEPATH=/usr/bin/gcc -DCMAKE_CXX_COMPILER:FILEPATH=/usr/bin/g++ -S/home/hamiachi/Desktop/ParaPano -B/home/hamiachi/Desktop/ParaPano/build -G "Unix Makefiles"
/usr/bin/cmake --build /home/hamiachi/Desktop/ParaPano/build --config Debug --target all -j 10 
cd /home/hamiachi/Desktop/ParaPano/build
./ParaPano