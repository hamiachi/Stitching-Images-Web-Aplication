const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/get-file', (req, res) => {
  const userDownloadsPath = path.join(process.env.USERPROFILE, 'Downloads');
  const filePath = path.join(userDownloadsPath, 'result.jpg');
  res.sendFile(filePath);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});