if [ -f /home/hamiachi/Downloads/image_1.png ]
then
	rm /home/hamiachi/Downloads/image_*.png /home/hamiachi/Downloads/result.jpg /home/hamiachi/Downloads/count.txt
	
fi